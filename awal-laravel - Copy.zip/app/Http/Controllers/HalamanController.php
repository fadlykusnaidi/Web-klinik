<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HalamanController extends Controller
{
    function index()
    {

    }
    function tentang()
    {

    }
    function kontak()
    {
        
    }
}
